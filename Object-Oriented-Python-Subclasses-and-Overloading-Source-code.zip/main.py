from enemy import Enemy, Troll

ugly_troll = Troll()
print("Ugly troll - {}".format(ugly_troll))

another_troll = Troll("Ug", 18, 1)
print("Another troll - {}".format(another_troll))

brother = Enemy("Urg", 23)
print(brother)
