letters = "abcdefghijklmnopqrstuvwxyz"

backwards = letters[::-1]
print(backwards)
