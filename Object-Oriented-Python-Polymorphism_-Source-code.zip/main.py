a =3
b = "tim"
c = 1, 2, 3

print(a)
print(b)
print(c)
