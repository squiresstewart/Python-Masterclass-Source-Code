import blackjack

# blackjack._deal_card(blackjack.dealer_card_frame)
# blackjack.play()

personal_details = ("Tim", 24, "Australia")

name, _, country = personal_details
print(name, country)
print(_)
